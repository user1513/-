var struct__t_flag_group =
[
    [ "event", "struct__t_flag_group.html#a8b516ab130f86e4b15ca025c98c3dc53", null ],
    [ "flags", "struct__t_flag_group.html#a773b39d480759f67926cb18ae2219281", null ]
];