var struct__t_flag_group_info =
[
    [ "flags", "struct__t_flag_group_info.html#a773b39d480759f67926cb18ae2219281", null ],
    [ "taskCount", "struct__t_flag_group_info.html#a80462c64b9184115aa568f08227f7f4a", null ]
];