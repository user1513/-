var t_switch_8c =
[
    [ "MEM32", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gade1e623e8a7851917439eeac2019ff3f", null ],
    [ "MEM8", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gac66df9e288958f808f7308f40d5ebd66", null ],
    [ "NVIC_INT_CTRL", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gafa1ca44ad548bf5bfa2f19d7438c722a", null ],
    [ "NVIC_PENDSV_PRI", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#ga3612aa5e26b7da530145fdddce3850ce", null ],
    [ "NVIC_PENDSVSET", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#ga11166a59c430ba34e6da8e20571b58d7", null ],
    [ "NVIC_SYSPRI2", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#ga23694ffa1ac38dfdfcc1ae1160be7397", null ],
    [ "PendSV_Handler", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gad628297c6eafc9b3a38fdd08377b42c5", null ],
    [ "saveAndLoadStackAddr", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gae823575cc1cd55db2bbc40292ec5d9e7", null ],
    [ "tTaskEnterCritical", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gab4d6c802c474b9071f48312bed3dec74", null ],
    [ "tTaskExitCritical", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#ga21b4efbc4cb710d7d0e71678d2b13e53", null ],
    [ "tTaskRunFirst", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#ga0fb8703674b7e263ae5b825af16cbce5", null ],
    [ "tTaskSwitch", "group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#ga0cd2c487eac7429325389fa3ee59867d", null ]
];