var annotated_dup =
[
    [ "_tEvent", "struct__t_event.html", "struct__t_event" ],
    [ "_tFlagGroup", "struct__t_flag_group.html", "struct__t_flag_group" ],
    [ "_tFlagGroupInfo", "struct__t_flag_group_info.html", "struct__t_flag_group_info" ],
    [ "_tList", "struct__t_list.html", "struct__t_list" ],
    [ "_tMbox", "struct__t_mbox.html", "struct__t_mbox" ],
    [ "_tMboxInfo", "struct__t_mbox_info.html", "struct__t_mbox_info" ],
    [ "_tMemBlock", "struct__t_mem_block.html", "struct__t_mem_block" ],
    [ "_tMemBlockInfo", "struct__t_mem_block_info.html", "struct__t_mem_block_info" ],
    [ "_tMutex", "struct__t_mutex.html", "struct__t_mutex" ],
    [ "_tMutexInfo", "struct__t_mutex_info.html", "struct__t_mutex_info" ],
    [ "_tNode", "struct__t_node.html", "struct__t_node" ],
    [ "_tSem", "struct__t_sem.html", "struct__t_sem" ],
    [ "_tSemInfo", "struct__t_sem_info.html", "struct__t_sem_info" ],
    [ "_tSlist", "struct__t_slist.html", "struct__t_slist" ],
    [ "_tSnode", "struct__t_snode.html", "struct__t_snode" ],
    [ "_tTask", "struct__t_task.html", "struct__t_task" ],
    [ "_tTaskInfo", "struct__t_task_info.html", "struct__t_task_info" ],
    [ "_tTimer", "struct__t_timer.html", "struct__t_timer" ],
    [ "_tTimerInfo", "struct__t_timer_info.html", "struct__t_timer_info" ],
    [ "tBitmap", "structt_bitmap.html", "structt_bitmap" ]
];