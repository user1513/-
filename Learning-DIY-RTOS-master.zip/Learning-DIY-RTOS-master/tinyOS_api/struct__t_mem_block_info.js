var struct__t_mem_block_info =
[
    [ "blockSize", "struct__t_mem_block_info.html#ab6558f40a619c2502fbc24c880fd4fb0", null ],
    [ "count", "struct__t_mem_block_info.html#a86988a65e0d3ece7990c032c159786d6", null ],
    [ "maxCount", "struct__t_mem_block_info.html#a1cc8a4ba5eee24b560f9869012941e91", null ],
    [ "taskCount", "struct__t_mem_block_info.html#a80462c64b9184115aa568f08227f7f4a", null ]
];