var struct__t_event =
[
    [ "type", "struct__t_event.html#ad508084452df36f9d0cca3196622a0e1", null ],
    [ "waitList", "struct__t_event.html#a8e54a36f1038a12d9206c6ed20fab2a2", null ]
];