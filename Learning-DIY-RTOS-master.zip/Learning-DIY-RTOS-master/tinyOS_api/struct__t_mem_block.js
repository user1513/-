var struct__t_mem_block =
[
    [ "blockList", "struct__t_mem_block.html#a097b552e5270ca956f34af77c4b5aadf", null ],
    [ "blockSize", "struct__t_mem_block.html#ab6558f40a619c2502fbc24c880fd4fb0", null ],
    [ "event", "struct__t_mem_block.html#a8b516ab130f86e4b15ca025c98c3dc53", null ],
    [ "maxCount", "struct__t_mem_block.html#a1cc8a4ba5eee24b560f9869012941e91", null ],
    [ "memStart", "struct__t_mem_block.html#a278e5d28605731490bb61cb8d313a5f3", null ]
];