var t_config_8h =
[
    [ "TINYOS_ENABLE_CPUUSAGE_STAT", "t_config_8h.html#a3333b6699e9d76e2bd1b749831fdcf6e", null ],
    [ "TINYOS_ENABLE_FLAGGROUP", "t_config_8h.html#a18e804e5ce9a9cd424ab90475ab9a2cb", null ],
    [ "TINYOS_ENABLE_HOOKS", "t_config_8h.html#a98cb5de816aa04e5ef21e8c357dfc075", null ],
    [ "TINYOS_ENABLE_MBOX", "t_config_8h.html#ab0bcd54cdfcad79cb7f77edb89269b31", null ],
    [ "TINYOS_ENABLE_MEMBLOCK", "t_config_8h.html#a6d583134f088f75a8a7bb3daafbb5b36", null ],
    [ "TINYOS_ENABLE_MUTEX", "t_config_8h.html#ac8a2fd49338934be50b067aa5ec2e8cc", null ],
    [ "TINYOS_ENABLE_SEM", "t_config_8h.html#a538ccfd366ca8899937162cbeb84907f", null ],
    [ "TINYOS_ENABLE_TIMER", "t_config_8h.html#a710db0aad10f28e8f46b36e6a3576dd5", null ],
    [ "TINYOS_IDLETASK_STACK_SIZE", "t_config_8h.html#ab3120bbe43b96f67a2cbdff3e998581a", null ],
    [ "TINYOS_PRO_COUNT", "t_config_8h.html#a66ba0d84eb6b37a000d0de9fab92e323", null ],
    [ "TINYOS_SLICE_MAX", "t_config_8h.html#af6ae9f93a379fad4f78f5aa21f2c66e1", null ],
    [ "TINYOS_SYSTICK_MS", "t_config_8h.html#a319285ff5e6e6bd538475ff8caef7ef0", null ],
    [ "TINYOS_TIMERTASK_PRIO", "t_config_8h.html#ac360e657d8a7cbe5e8b3398dd2887ba1", null ],
    [ "TINYOS_TIMERTASK_STACK_SIZE", "t_config_8h.html#a5b21e8b2c1f96ba51307e8e9a2e85879", null ]
];