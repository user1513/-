var searchData=
[
  ['delaynode',['delayNode',['../struct__t_task.html#a069fafc88eadffde425a5d9fc895d85a',1,'_tTask']]],
  ['delayticks',['delayTicks',['../struct__t_task.html#a0c1ef2b42e60232fd2355246df290c68',1,'_tTask::delayTicks()'],['../struct__t_task_info.html#a0c1ef2b42e60232fd2355246df290c68',1,'_tTaskInfo::delayTicks()'],['../struct__t_timer.html#a0c1ef2b42e60232fd2355246df290c68',1,'_tTimer::delayTicks()']]],
  ['durationticks',['durationTicks',['../struct__t_timer.html#a95f8cbd7a4ba89fc9ae542eb04a24bc0',1,'_tTimer::durationTicks()'],['../struct__t_timer_info.html#a95f8cbd7a4ba89fc9ae542eb04a24bc0',1,'_tTimerInfo::durationTicks()']]]
];
