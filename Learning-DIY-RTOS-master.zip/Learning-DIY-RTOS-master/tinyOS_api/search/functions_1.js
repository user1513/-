var searchData=
[
  ['main',['main',['../group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gae66f6b31b5ad750f1fe042a706a4e3d4',1,'tCore.c']]]
];
