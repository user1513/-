var searchData=
[
  ['pendsv_5fhandler',['PendSV_Handler',['../group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gad628297c6eafc9b3a38fdd08377b42c5',1,'tSwitch.c']]]
];
