var indexSectionsWithContent =
{
  0: "_abcdefhilmnoprstwäåèé",
  1: "_t",
  2: "mt",
  3: "impst",
  4: "abcdefhilmnoprstw",
  5: "t",
  6: "_",
  7: "t",
  8: "häåèé",
  9: "é"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

