var searchData=
[
  ['headnode',['headNode',['../struct__t_list.html#a6e52b98a705384bda92a389d838065b3',1,'_tList']]]
];
