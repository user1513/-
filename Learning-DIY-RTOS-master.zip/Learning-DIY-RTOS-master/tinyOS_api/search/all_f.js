var searchData=
[
  ['saveandloadstackaddr',['saveAndLoadStackAddr',['../group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gae823575cc1cd55db2bbc40292ec5d9e7',1,'tSwitch.c']]],
  ['schedlockcount',['schedLockCount',['../group___xE5_x86_x85_xE6_xA0_xB8_xE6_xA0_xB8_xE5_xBF_x83.html#gade0d53c8948da99a0d522eedb3ebf92a',1,'tCore.c']]],
  ['slice',['slice',['../struct__t_task.html#a4fe7f19d35a11368d300b99348451fdd',1,'_tTask::slice()'],['../struct__t_task_info.html#a4fe7f19d35a11368d300b99348451fdd',1,'_tTaskInfo::slice()']]],
  ['stack',['stack',['../struct__t_task.html#a1abf78464029077a8080178b9e04745c',1,'_tTask']]],
  ['stackbase',['stackBase',['../struct__t_task.html#a57eb489f59ea6a56ccff2efea7f92c33',1,'_tTask']]],
  ['stackfree',['stackFree',['../struct__t_task_info.html#ab8b8202c533d50459f39dfab24e8873d',1,'_tTaskInfo']]],
  ['stacksize',['stackSize',['../struct__t_task.html#ae20ace955faaa4fb797b69b75feef3d3',1,'_tTask::stackSize()'],['../struct__t_task_info.html#ae20ace955faaa4fb797b69b75feef3d3',1,'_tTaskInfo::stackSize()']]],
  ['startdelayticks',['startDelayTicks',['../struct__t_timer.html#acecf013811265c398517a464e7e6f7b2',1,'_tTimer::startDelayTicks()'],['../struct__t_timer_info.html#acecf013811265c398517a464e7e6f7b2',1,'_tTimerInfo::startDelayTicks()']]],
  ['state',['state',['../struct__t_task.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2',1,'_tTask::state()'],['../struct__t_task_info.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2',1,'_tTaskInfo::state()'],['../struct__t_timer.html#a1554a5dc790e401b90c319aad88f51dc',1,'_tTimer::state()'],['../struct__t_timer_info.html#a1554a5dc790e401b90c319aad88f51dc',1,'_tTimerInfo::state()']]],
  ['suspendcount',['suspendCount',['../struct__t_task.html#a70023864793bcef3ab18d4a66832ca6d',1,'_tTask::suspendCount()'],['../struct__t_task_info.html#a70023864793bcef3ab18d4a66832ca6d',1,'_tTaskInfo::suspendCount()']]]
];
