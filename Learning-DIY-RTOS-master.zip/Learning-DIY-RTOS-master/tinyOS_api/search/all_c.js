var searchData=
[
  ['owner',['owner',['../struct__t_mutex.html#af99fea13bfba6d0a457c2779fa8ecc5a',1,'_tMutex::owner()'],['../struct__t_mutex_info.html#af99fea13bfba6d0a457c2779fa8ecc5a',1,'_tMutexInfo::owner()']]],
  ['owneroriginalprio',['ownerOriginalPrio',['../struct__t_mutex.html#aa1d8803bb70576a417cba7092640ebd3',1,'_tMutex']]],
  ['ownerprio',['ownerPrio',['../struct__t_mutex_info.html#a2ad329dc18ddf3afd170e73535c5907a',1,'_tMutexInfo']]]
];
