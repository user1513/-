var searchData=
[
  ['read',['read',['../struct__t_mbox.html#a0a71cf941cf2509857d61e1443ad8eaa',1,'_tMbox']]],
  ['requestdeleteflag',['requestDeleteFlag',['../struct__t_task.html#a3b197900b58be56e296d46207dec079f',1,'_tTask']]]
];
