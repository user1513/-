var struct__t_list =
[
    [ "headNode", "struct__t_list.html#a6e52b98a705384bda92a389d838065b3", null ],
    [ "nodeCount", "struct__t_list.html#a9ff3c0ff509d8eb055d29faa0ec185a1", null ]
];