var group___xE9_x82_xAE_xE7_xAE_xB1 =
[
    [ "_tMbox", "struct__t_mbox.html", [
      [ "count", "struct__t_mbox.html#a86988a65e0d3ece7990c032c159786d6", null ],
      [ "event", "struct__t_mbox.html#a8b516ab130f86e4b15ca025c98c3dc53", null ],
      [ "maxCount", "struct__t_mbox.html#a1cc8a4ba5eee24b560f9869012941e91", null ],
      [ "msgBuffer", "struct__t_mbox.html#a42b4bab76140c12b77b72ec381001c6c", null ],
      [ "read", "struct__t_mbox.html#a0a71cf941cf2509857d61e1443ad8eaa", null ],
      [ "write", "struct__t_mbox.html#ac4c9f9c5eac363cc22ecc18669cc3891", null ]
    ] ],
    [ "_tMboxInfo", "struct__t_mbox_info.html", [
      [ "count", "struct__t_mbox_info.html#a86988a65e0d3ece7990c032c159786d6", null ],
      [ "maxCount", "struct__t_mbox_info.html#a1cc8a4ba5eee24b560f9869012941e91", null ],
      [ "taskCount", "struct__t_mbox_info.html#a80462c64b9184115aa568f08227f7f4a", null ]
    ] ],
    [ "tMBOXSendFront", "group___xE9_x82_xAE_xE7_xAE_xB1.html#ga12536685a5e231dea9a6433c77c5491f", null ],
    [ "tMBOXSendNormal", "group___xE9_x82_xAE_xE7_xAE_xB1.html#gae98d38e0915738d565f697b203e667b1", null ],
    [ "tMbox", "group___xE9_x82_xAE_xE7_xAE_xB1.html#gaf02fc8927d941b8983e485f054dee3c8", null ],
    [ "tMboxInfo", "group___xE9_x82_xAE_xE7_xAE_xB1.html#gace85309e5c44e993e993af3a8e1b00c2", null ],
    [ "tMboxDestroy", "group___xE9_x82_xAE_xE7_xAE_xB1.html#ga3473c47a3e47521c023738edf046252f", null ],
    [ "tMboxFlush", "group___xE9_x82_xAE_xE7_xAE_xB1.html#gaa37bb91261b5b19d6c7d72a88a52a457", null ],
    [ "tMboxGetInfo", "group___xE9_x82_xAE_xE7_xAE_xB1.html#gae8b08f83ec686fdd556c12baaa3a4a48", null ],
    [ "tMboxInit", "group___xE9_x82_xAE_xE7_xAE_xB1.html#gae6bb5e2c3b40c25946cd3783387ef53e", null ],
    [ "tMboxNotify", "group___xE9_x82_xAE_xE7_xAE_xB1.html#ga77710ad1a67a5bdfe7a918cfd3b1ae6a", null ],
    [ "tMboxNoWaitGet", "group___xE9_x82_xAE_xE7_xAE_xB1.html#ga24727b25fe713d402f2f3aa21d6ea98b", null ],
    [ "tMboxWait", "group___xE9_x82_xAE_xE7_xAE_xB1.html#ga23993f613e24cf58555aae3b7606722d", null ]
];